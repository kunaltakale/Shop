package com.swapra.project1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiveProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(LiveProject1Application.class, args);
	}

}
