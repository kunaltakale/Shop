package com.swapra.project1.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.swapra.project1.entity.Bill;

@Service
public class BillService {

	public List<Bill> getAllBills() {
		// TODO Auto-generated method stub
		return null;
	}
    // Your service methods
}
