

package com.swapra.project1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.swapra.project1.entity.BillItem;

public interface BillItemRepository extends JpaRepository<BillItem, Long> {
    // Custom query methods can be added here if needed
}
