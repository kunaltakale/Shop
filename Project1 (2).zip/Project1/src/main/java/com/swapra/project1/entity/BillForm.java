package com.swapra.project1.entity;

public class BillForm {
	  private Long clientId;
	    private Long[] itemId;
	    private Double[] price;
	    private Integer[] quantity;
	    private Double[] total;
	public Long getClientId() {
		return clientId;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
	public Long[] getItemId() {
		return itemId;
	}
	public void setItemId(Long[] itemId) {
		this.itemId = itemId;
	}
	public Double[] getPrice() {
		return price;
	}
	public void setPrice(Double[] price) {
		this.price = price;
	}
	public Integer[] getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer[] quantity) {
		this.quantity = quantity;
	}
	public Double[] getTotal() {
		return total;
	}
	public void setTotal(Double[] total) {
		this.total = total;
	}

    // Getters and setters
}
