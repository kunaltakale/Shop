package com.swapra.project1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.swapra.project1.entity.Bill;

public interface BillRepository extends JpaRepository<Bill, Long> {

}
