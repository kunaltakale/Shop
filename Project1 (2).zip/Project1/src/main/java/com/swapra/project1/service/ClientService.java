package com.swapra.project1.service;

import org.springframework.stereotype.Service;

import com.swapra.project1.entity.Client;
import com.swapra.project1.repository.ClientRepository;

import java.util.List;

@Service
public class ClientService {

    private final ClientRepository clientRepository;

    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    public Client getClientById(Long id) {
        return clientRepository.findById(id).orElse(null);
    }
}
