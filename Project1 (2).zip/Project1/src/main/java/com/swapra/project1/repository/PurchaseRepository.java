package com.swapra.project1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.swapra.project1.entity.Purchase;


public interface PurchaseRepository extends JpaRepository<Purchase, Long> {
    List<Purchase> findByClientId(Long clientId);
}
