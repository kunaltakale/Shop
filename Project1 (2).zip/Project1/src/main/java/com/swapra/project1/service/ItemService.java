package com.swapra.project1.service;

import java.util.List;
import com.swapra.project1.entity.Item;

public interface ItemService {
    Item findById(Long id);
    void save(Item item);
    List<Item> getItemsByCategory(Long categoryId);
}
