	package com.swapra.project1.entity;
	
	import jakarta.persistence.*;
	
	@Entity
	public class BillItem {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	
	    @ManyToOne
	    @JoinColumn(name = "bill_id")
	    private Bill bill;
	
	    @ManyToOne
	    @JoinColumn(name = "item_id")
	    private Item item;
	
	    private Double price;
	    private Integer quantity;
	    private Double total;
	
	    public Long getId() {
	        return id;
	    }
	
	    public void setId(Long id) {
	        this.id = id;
	    }
	
	    public Bill getBill() {
	        return bill;
	    }
	
	    public void setBill(Bill bill) {
	        this.bill = bill;
	    }
	
	    public Item getItem() {
	        return item;
	    }
	
	    public void setItem(Item item) {
	        this.item = item;
	    }
	
	    public Double getPrice() {
	        return price;
	    }
	
	    public void setPrice(Double price) {
	        this.price = price;
	    }
	
	    public Integer getQuantity() {
	        return quantity;
	    }
	
	    public void setQuantity(Integer quantity) {
	        this.quantity = quantity;
	    }
	
	    public Double getTotal() {
	        return total;
	    }
	
	    public void setTotal(Double total) {
	        this.total = total;
	    }
	}
