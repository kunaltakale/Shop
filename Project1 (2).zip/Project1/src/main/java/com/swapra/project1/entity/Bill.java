	package com.swapra.project1.entity;
	
	import jakarta.persistence.*;
	import java.time.LocalDateTime;
	import java.util.ArrayList;
	import java.util.List;
	
	@Entity
	public class Bill {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	
	    @ManyToOne
	    @JoinColumn(name = "client_id")
	    private Client client;
	
	    private LocalDateTime date;
	
	    @OneToMany(mappedBy = "bill", cascade = CascadeType.ALL, orphanRemoval = true)
	    private List<BillItem> items = new ArrayList<>();
	
	    private Double totalAmount;
	
	    public Long getId() {
	        return id;
	    }
	
	    public void setId(Long id) {
	        this.id = id;
	    }
	
	    public Client getClient() {
	        return client;
	    }
	
	    public void setClient(Client client) {
	        this.client = client;
	    }
	
	    public LocalDateTime getDate() {
	        return date;
	    }
	
	    public void setDate(LocalDateTime date) {
	        this.date = date;
	    }
	
	    public List<BillItem> getItems() {
	        return items;
	    }
	
	    public void setItems(List<BillItem> items) {
	        this.items = items;
	    }
	
	    public Double getTotalAmount() {
	        return totalAmount;
	    }
	
	    public void setTotalAmount(Double totalAmount) {
	        this.totalAmount = totalAmount;
	    }
	}
