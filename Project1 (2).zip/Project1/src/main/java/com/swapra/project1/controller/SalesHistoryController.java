package com.swapra.project1.controller;

import com.swapra.project1.entity.BillItem;
import com.swapra.project1.repository.BillItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class SalesHistoryController {

    @Autowired
    private BillItemRepository billItemRepository;

    @GetMapping("/sales-history")
    public String salesHistory(Model model) {
        List<BillItem> billItems = (List<BillItem>) billItemRepository.findAll();

        // Calculate total quantity per product
        Map<String, Integer> totalQuantityPerProduct = billItems.stream()
                .collect(Collectors.groupingBy(
                        item -> item.getItem().getItemName(),
                        Collectors.summingInt(BillItem::getQuantity)
                ));

        model.addAttribute("totalQuantityPerProduct", totalQuantityPerProduct.entrySet());

        return "sales-history"; // Thymeleaf template name
    }
}
