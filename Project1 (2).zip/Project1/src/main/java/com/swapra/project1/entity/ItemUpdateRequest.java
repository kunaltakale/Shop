package com.swapra.project1.entity;

public class ItemUpdateRequest {
    private Long id;
    private int godownStock;
    private int shopStock;
    private int stockLimit;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getGodownStock() {
		return godownStock;
	}
	public void setGodownStock(int godownStock) {
		this.godownStock = godownStock;
	}
	public int getShopStock() {
		return shopStock;
	}
	public void setShopStock(int shopStock) {
		this.shopStock = shopStock;
	}
	public int getStockLimit() {
		return stockLimit;
	}
	public void setStockLimit(int stockLimit) {
		this.stockLimit = stockLimit;
	}

    // Getters and Setters
}
