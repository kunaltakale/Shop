package com.swapra.project1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.swapra.project1.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
	User findByUserNameAndPassword(String username, String password);
}
