package com.swapra.project1.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.swapra.project1.entity.Bill;
import com.swapra.project1.entity.BillForm;
import com.swapra.project1.entity.BillItem;
import com.swapra.project1.entity.Category;
import com.swapra.project1.entity.Client;
import com.swapra.project1.entity.Item;
import com.swapra.project1.entity.ItemUpdateRequest;
import com.swapra.project1.entity.Purchase;
import com.swapra.project1.entity.User;
import com.swapra.project1.repository.BillItemRepository;
import com.swapra.project1.repository.BillRepository;
import com.swapra.project1.repository.CategoryRepository;
import com.swapra.project1.repository.ClientRepository;
import com.swapra.project1.repository.ItemRepository;
import com.swapra.project1.repository.PurchaseRepository;
import com.swapra.project1.repository.UserRepository;
import com.swapra.project1.service.BillService;
import com.swapra.project1.service.ItemService;

import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class MainController {
    
    private static final Logger logger = LoggerFactory.getLogger(MainController.class);
    
    @Autowired
    UserRepository userRepository;
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    @Autowired
    private ItemRepository itemRepository;
    
    @Autowired 
    private BillRepository billRepository;
    
    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private ItemService itemService;
    
    @Autowired
    private BillItemRepository billItemRepository;
    
    @GetMapping("/")
    public String loginPage() {
        return "index"; // Return your login page view name
    }
    
    @PostMapping("/login")
    public String login(@RequestParam("userName") String username,
                        @RequestParam("password") String password,
                        Model model, RedirectAttributes redirectAttributes) {
        User loggedInUser = userRepository.findByUserNameAndPassword(username, password);
        if (loggedInUser != null) {
            // Redirect to dashboard page upon successful login
            return "redirect:/dashboard"; // Ensure /dashboard mapping exists in your controller
        } else {
            // Add error message to flash attributes
            redirectAttributes.addFlashAttribute("error", "Invalid username or password");
            // Redirect back to the login page
            return "redirect:/";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        // Add dashboard logic here if needed
        return "dashboard"; // Return the name of your dashboard Thymeleaf view
    }

    @GetMapping("/addItem")
    public String addItem(Model model) {
        Iterable<Category> categories = categoryRepository.findAll();
        model.addAttribute("categories", categories);
        return "addItem"; // Return the name of your Thymeleaf template
    }

    @PostMapping("/saveItems")
    public String saveItems(
        @RequestParam("categoryId") Long categoryId,
        @RequestParam("itemName") String[] itemNames,
        @RequestParam("unit") String[] units,
        @RequestParam("tax") String[] taxes,
        @RequestParam("rate") double[] rates,
        @RequestParam("stockLimit") int[] stockLimits,
        @RequestParam("shopStock") int[] shopStocks,
        @RequestParam("godownStock") int[] godownStocks,
        @RequestParam("barcode") String[] barcodes,
        RedirectAttributes redirectAttributes
    ) {
        Category category = categoryRepository.findById(categoryId)
            .orElseThrow(() -> new IllegalArgumentException("Invalid category ID"));

        for (int i = 0; i < itemNames.length; i++) {
            Item item = new Item();
            item.setCategory(category);
            item.setItemName(itemNames[i]);
            item.setUnit(units[i]);
            item.setTax(taxes[i] + "%");
            item.setRate(rates[i]);
            item.setStockLimit(stockLimits[i]);
            item.setShopStock(shopStocks[i]);
            item.setGodownStock(godownStocks[i]);
            item.setBarcode(barcodes[i]);

            itemRepository.save(item);
        }
        redirectAttributes.addFlashAttribute("success", "Item added successfully!");
        return "redirect:/addItem";
    }

    @GetMapping("/addCategory")
    public String showAddCategoryForm() {
        return "addCategory";
    }

    @PostMapping("/saveCategory")
    public String saveCategory(@ModelAttribute("category") Category category, RedirectAttributes redirectAttributes) {
        // Check if the category already exists
        Category existingCategory = categoryRepository.findByCategoryName(category.getCategoryName());
        if (existingCategory != null) {
            // Category already exists, add an error message
            redirectAttributes.addFlashAttribute("error", "Category with same name already exists");
            return "redirect:/addCategory";
        }

        // Category does not exist, save it
        categoryRepository.save(category);
        redirectAttributes.addFlashAttribute("success", "Category added successfully");
        return "redirect:/addCategory";
    }

    @GetMapping("/logout")
    public String logOut() {
        return "redirect:/";
    }

    @GetMapping("/addClient")
    public String addClient() {
        return "addClient";
    }

    @PostMapping("/saveClientDetails")
    public String addClientDetails(@ModelAttribute("product") Client client, RedirectAttributes redirectAttributes) {
        clientRepository.save(client);
        redirectAttributes.addFlashAttribute("success", "Client details added successfully");
        return "redirect:/addClient"; // Redirect to product listing page
    }

    @GetMapping("/clients")
    public String getClients(Model model) {
        List<Client> clients = clientRepository.findAll();
        model.addAttribute("clients", clients);
        return "clientList";
    }

    
    @GetMapping("/itemList")
    public String getItems(Model model)
    {
    	List<Item> items = itemRepository.findAll();
    	model.addAttribute("items",items);
		return "itemList";
    }
    
    @GetMapping("/modifyItem")
    public String modifyItem(Model model)
    {
    	List<Item> items = itemRepository.findAll();
    	model.addAttribute("items",items);
    	 Iterable<Category> categories = categoryRepository.findAll();
         model.addAttribute("categories", categories);
		return "modifyItem";
    }
    
    @GetMapping("/getStock")
    public String getStock(Model model)
    {
    	List<Item> items = itemRepository.findAll();
    	model.addAttribute("items",items);
		return "stock";
    }
    
    
    @GetMapping("/manageStock")
    public String manageStock(Model model)
    {
    	List<Item> items = itemRepository.findAll();
    	model.addAttribute("items",items);
		return "manageStock";
    }
    
    @PostMapping("/updateStock")
    @ResponseBody
    public ResponseEntity<?> updateStock(@RequestBody Item updatedItem) {
        try {
            Optional<Item> existingItemOptional = itemRepository.findById(updatedItem.getId());
            if (existingItemOptional.isPresent()) {
                Item existingItem = existingItemOptional.get();
                existingItem.setItemName(updatedItem.getItemName());
                existingItem.setUnit(updatedItem.getUnit());
                existingItem.setTax(updatedItem.getTax());
                existingItem.setRate(updatedItem.getRate());
                existingItem.setStockLimit(updatedItem.getStockLimit());
                existingItem.setShopStock(updatedItem.getShopStock());
                existingItem.setGodownStock(updatedItem.getGodownStock());
                existingItem.setBarcode(updatedItem.getBarcode());

                // Fetch and set the category
                Category category = categoryRepository.findById(updatedItem.getCategory().getId())
                    .orElseThrow(() -> new RuntimeException("Category not found"));
                existingItem.setCategory(category);

                itemRepository.save(existingItem);
                return ResponseEntity.ok().body(Collections.singletonMap("success", true));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("success", false));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonMap("success", false));
        }
    }





    @GetMapping("/clientBill/{clientId}")
    public String getClientBill(@PathVariable("clientId") Long clientId, Model model) {
        Client client = clientRepository.findById(clientId).orElse(null);
//        List<Purchase> bills = purchaseRepository.findByClientId(clientId);
        List<Item> items = itemRepository.findAll(); // Assuming you have an ItemRepository

        model.addAttribute("client", client);
//        model.addAttribute("bills", bills != null ? bills : new ArrayList<>());
        model.addAttribute("items", items);
        return "clientBill";
    }

   


//    @GetMapping("/deleteClient/{id}")
//    public String deleteClient(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
//        try {
//            clientRepository.deleteById(id);
//            redirectAttributes.addFlashAttribute("successMessage", "Client deleted successfully.");
//            logger.info("Client with id {} deleted successfully.", id);
//        } catch (Exception e) {
//            redirectAttributes.addFlashAttribute("errorMessage", "Error deleting client: " + e.getMessage());
//            logger.error("Error deleting client with id {}: {}", id, e.getMessage());
//        }
//        return "redirect:/clients"; // Redirect to the clients list page
//    }
//    
//    @DeleteMapping("/deleteClient/{id}")
//    public String deleteClient(@PathVariable("id") Long id) {
//        clientRepository.deleteById(id); // Delete client directly from database
//        return "redirect:/clients"; // Redirect to client list page after deletion
//    }
    
//    
//    @GetMapping("/purchase")
//    public String purchase(Model model) {
//        List<Client> clients = clientRepository.findAll();
//        model.addAttribute("clients", clients);
//        return "purchase";
//    }
    
    @DeleteMapping("/deleteClient/{id}")
    public String deleteClient(@PathVariable("id") Long id) {
        try {
            clientRepository.deleteById(id); // Delete client directly from database
        } catch (Exception e) {
            e.printStackTrace(); // Log any exceptions for debugging
        }
        return "redirect:/clients"; // Redirect to client list page after deletion
    }

	
	    @PostMapping("/saveBill")
	    public String saveBill(@ModelAttribute BillForm billForm, RedirectAttributes redirectAttributes) {
	        Optional<Client> optionalClient = clientRepository.findById(billForm.getClientId());
	
	        if (optionalClient.isPresent()) {
	            Client client = optionalClient.get();
	            Bill bill = new Bill();
	            bill.setClient(client);
	            bill.setDate(LocalDateTime.now());
	
	            List<BillItem> billItems = new ArrayList<>();
	            double totalAmount = 0.0;
	
	            for (int i = 0; i < billForm.getItemId().length; i++) {
	                Long itemId = billForm.getItemId()[i];
	                Optional<Item> optionalItem = itemRepository.findById(itemId);
	
	                if (optionalItem.isPresent()) {
	                    Item item = optionalItem.get();
	
	                    if (item.getGodownStock() < billForm.getQuantity()[i]) {
	                        redirectAttributes.addFlashAttribute("error", "Not enough stock available for item: " + item.getItemName());
	                        return "redirect:/clientBill/" + client.getId();
	                    }
	
	                    item.setGodownStock(item.getGodownStock() - billForm.getQuantity()[i]);
	                    itemRepository.save(item);
	
	                    BillItem billItem = new BillItem();
	                    billItem.setBill(bill);
	                    billItem.setItem(item);
	                    billItem.setPrice(billForm.getPrice()[i]);
	                    billItem.setQuantity(billForm.getQuantity()[i]);
	                    billItem.setTotal(billForm.getTotal()[i]);
	                    billItems.add(billItem);
	
	                    totalAmount += billForm.getTotal()[i];
	                } else {
	                    redirectAttributes.addFlashAttribute("error", "Item not found");
	                    return "redirect:/clientBill/" + client.getId();
	                }
	            }
	
	            bill.setItems(billItems);
	            bill.setTotalAmount(totalAmount);
	            billRepository.save(bill);
	
	            redirectAttributes.addFlashAttribute("success", "Bill generated successfully");
	        } else {
	            redirectAttributes.addFlashAttribute("error", "Client not found");
	        }
	
	        return "redirect:/clients";
	    }



    
	    @GetMapping("/purchase")
	    public String getBillTable(Model model) {
	        List<Bill> bills = billRepository.findAll();
//	        List<BillItem> billItems = billItemRepository.findAll();
	        
	        model.addAttribute("bills", bills);
//	        model.addAttribute("billItems", billItems);

	        return "purchase";
	    }

}
