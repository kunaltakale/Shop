package com.swapra.project1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
